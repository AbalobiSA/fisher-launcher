# Java 7 for Android and Amazon-FireOS

This plugin attempts to convince Cordova to compile against Java 7 instead of Java 5 on Java platforms.

**Do only install if you need Java 7 and know why you need Java 7, this is NOT an update for the compiler**

### Installation

    cordova plugin add https://github.com/cvuser0/cordova-plugin-java7.git --link

#### This plugin is not to be installed along side it's little brother [cordova-plugin-java6](https://github.com/cvuser0/cordova-plugin-java6)
